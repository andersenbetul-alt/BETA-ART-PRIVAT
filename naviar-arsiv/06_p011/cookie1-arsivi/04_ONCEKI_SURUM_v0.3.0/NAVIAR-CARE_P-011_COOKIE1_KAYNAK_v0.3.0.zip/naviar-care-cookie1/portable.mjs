import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {render} from './public/render.js';
await mkdir('deliverables',{recursive:true});
const css=await readFile('public/styles.css','utf8'),svg=await readFile('public/assets/naviar-care.svg','utf8');
const content=(await readFile('public/content.js','utf8')).replace('export const copy','const copy');
const renderer=(await readFile('public/render.js','utf8')).replace("import {copy} from './content.js';",'').replace('export function render','function render');
let app=(await readFile('public/app.js','utf8')).replace("import {copy} from './content.js';",'').replace("import {render} from './render.js';",'').replace("location.pathname.split('/')[1] in copy?location.pathname.split('/')[1]:'nb'","new URLSearchParams(location.search).get('lang') in copy?new URLSearchParams(location.search).get('lang'):'nb'");
// Portable visual review intentionally has no backend and no analytics requests.
app=app.replace("async function event(name,section){","async function event(name,section){return;");
app=app.replace("async function api(path,data,token){","async function api(path,data,token){throw new Error('durable_database_required');");
const inlineLogo="data:image/svg+xml,"+encodeURIComponent(svg);
const ending=`document.querySelectorAll('a[href]').forEach(a=>{const h=a.getAttribute('href');if(/^\\/(nb|en|tr)\\/$/.test(h))a.setAttribute('href','?lang='+h.split('/')[1]);if(h==='/operations'){a.removeAttribute('href');a.textContent=({nb:'Drift: start kildepakken lokalt',en:'Operations: run the source package',tr:'Yönetim: kaynak paketini çalıştırın'})[lang];}});document.querySelector('.brand img').src=${JSON.stringify(inlineLogo)};`;
const html=`<!doctype html><html lang="nb"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta name="description" content="NAVIAR CARE visual development preview"><title>NAVIAR CARE</title><style>${css}</style></head><body><div id="app">${render('nb').replace('/assets/naviar-care.svg',inlineLogo)}</div><script>${content}\n${renderer}\n${app}\n${ending}</script></body></html>`;
await writeFile('deliverables/NAVIAR-CARE_P-011_COOKIE1_ONIZLEME.html',html);
console.log('Portable three-language visual preview generated; form submissions explicitly unavailable.');
